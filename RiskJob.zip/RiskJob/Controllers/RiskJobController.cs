﻿using System.Collections.Concurrent;
using Microsoft.AspNetCore.Mvc;

namespace RiskJob.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RiskJobController(ConcurrentDictionary<string, int> riskData) : ControllerBase
    {
        private readonly ConcurrentDictionary<string, int> _riskData = riskData;

        [HttpPost]
        [Route("/run-risk-job")]
        public ActionResult RunRiskJob()
        {
            string borrwerId = Guid.NewGuid().ToString();
            int riskSCore = new Random().Next(1, 101);

            _riskData.TryAdd(borrwerId, riskSCore);

            return Accepted(new { BorrowerId = borrwerId, RiskScore = riskSCore });
        }
    }
}
