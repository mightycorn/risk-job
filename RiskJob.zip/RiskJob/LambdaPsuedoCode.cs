﻿using System.Text.Json;

namespace PseudoCodeLambda
{
    public record BorrowerData(string BorrowerId, int RiskScore);

    public class Function
    {
        public class Result { 
            public bool Ok { get; set; } 
            public BorrowerData Data { get; set; } = default!; 
        }

        public Task<Result> FunctionHandler(ILambdaContext contest)
        {
            string borrowerId = Guid.NewGuid().ToString();
            int riskScore = Random.Shared.Next(1, 101);
            var data = new BorrowerData(borrowerId, riskScore);


            Result result = new Result { Ok = true, Data = data };

            return Task.FromResult(result);
        }
    }
}
